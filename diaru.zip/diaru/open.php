<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>

<?php
require_once "config.php";

error_reporting(0);
 $_GET['da'];
 $_GET['po'];
 $_GET['gen'];
 $_GET['tare'];

?>
<html>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<head>
   <style>
      .footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: pink;
   text-align: center;
}
.button {
  background-color: purple;
  border: pink;
  color: white;
  padding: 10px 20px;
  text-align: center;
  font-size: 16px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
  display: inline-block;
  text-decoration: none;
  cursor: pointer;
}



.button:hover {opacity: 1}

</style>
  <style>
* {
  box-sizing: border-box;
}


/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
   
    margin-top: 0;
  }
}
div.scrollmenu {
  background-color: #DB7093;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: gray;
}
.content {
  min-height: calc(100vh - 70px);
}
</style>

   </head>
<body background="diary.jpg"> <center>
	<h1  class="w3-opacity"> MY DIARY </h1>
 <div class="scrollmenu"><center>
     <a href="welcome.php">Home</a>
  <a href="home.php">Global Page </a>
  
  <a href="new.php">New </a>
  <a href="display.php">View </a>
   <a href="dispaly_count.php">Genre Count </a>
 
  <a href="display.php" >Edit </a>
  <a href="display.php">Delete </a>
  
  
  <a href="about.php">About Us</a>
  <a href="logout.php"> Log Out</a></center>
</div >
<div class="content">
   <form action="home.php" method="GET">
      <br>
        <b>User Name</b> <input type="text" name="dates" value="<?php echo $_GET['da']; ?>" readonly> <br>
        <b>Title</b> <input type="text" name="title" value="<?php echo $_GET['tit']; ?>" > <br>
        <b> Post</b> <br><textarea rows="10" cols="50" name="post" readonly><?php echo $_GET['po']; ?> </textarea>
      <br>
      
      <b>Genre</b> <input type="text" name="dates" value="<?php echo $_GET['gen']; ?>" readonly><br><br>
      <b>Date</b> <input type="text" name="dates" value="<?php echo $_GET['tare']; ?>" readonly><br>
      <b>
     
      <br>
      <input class="button" style="vertical-align:middle" type="submit" name="submit" value="Back">
   </form>
</div>
  

 <footer class="footer"  data-position="fixed">
  <p class="w3-medium">
  Designed and programmed by <a href="about.php" target="_blank"> Saba Siddiqua</a>
  </p>
</footer>

   </body>
</html>