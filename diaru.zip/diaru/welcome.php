<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<head>
    
<title> Welcome</title>
<style>
.mySlides {

height:360px;

}
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: gray ;
   color: pink;
   text-align: center;
}

div.scrollmenu {
  background-color: #DB7093;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: gray;
}

</style>
</head>
<body background="diary.jpg"> <center>
    <section>
  <img class="mySlides" src="slide1.png"
  style="width:100%">
  <img class="mySlides" src="slide2.jpg"
  style="width:100%">
  <img class="mySlides" src="slide6.jpg"
  style="width:100%">
  <img class="mySlides" src="slide3.jpg"
  style="width:100%">
  <img class="mySlides" src="slide5.jpg"
  style="width:100%">
</section>
<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 3000);
}
</script>


   

    <p>
<div class="scrollmenu">
    <a href="welcome.php">Home</a>
  <a href="home.php">Global Page </a>
  
  <a href="new.php">New </a>
  <a href="display.php">View </a>
   <a href="dispaly_count.php">Genre Count </a>
 
  <a href="display.php" >Edit </a>
  <a href="display.php">Delete </a>
  
  
  <a href="about.php">About Us</a>
  <a href="logout.php"> Log Out</a></div>
 <section class="w3-container w3-center w3-content" style="max-width:600px">
             <h1 >Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>. Welcome to Your Personal Diary.</h1>
    
    <div>
        <p align='center'> <h1 class="w3-opacity">MY DIARY</h1> </p>
  </section>

    <section class="w3-container w3-center w3-content" style="max-width:600px">
  <p > <h3> <b>"The life of every person is like a diary in which he/she means to write one story, and writes another.
"</b></h3>
.</p>
</section>
<?php
    ?>
    </div>
    
    <p>
       <br>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
    </p>
    <footer class="footer" >
  <p class="w3-medium">
  Designed and programmed by <a href="about.php" target="_blank"> Saba Siddiqua</a>
  </p>
</footer>

</center>
</body>
</html>