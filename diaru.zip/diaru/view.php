<?php 
session_start(); 
 if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>
 
<?php
//including the database connection file
?>
 
<html>
<head>
    <title>Homepage</title>
</head>
 
<body>
    <a href="index.php">Home</a> | <a href="add.html">Add New Data</a> |<a href="logout.php">Logout</a>

<br/><br/>
    
<table width='80%' border=0>
    <tr bgcolor='#CCCCCC'>
        <td>Product_Name</td>
        <td>Product_Quantity</td>
        <td>Product_Price (euro)</td>
        <td>Update</td>
    </tr>
    <?php
    include_once("connection.php");
$name=$_SESSION["username"];

$sql="select * from products";
//fetching data in descending order (lastest entry first)
$result= mysqli_query($link,$sql);
if (!$result){
   die('Invalid query: '.mysqli_error($link));
}
    while($res=mysqli_fetch_assoc($result)) {        
        echo "<tr>
         <td>".$res['Product_Name']."</td>
         <td>".$res['Product_Quantity']."</td>
         <td>".$res['Product_Price']."</td>
    
       
        	<td> <a href='edit.php?name=$result[Product_Name]&po=$result[Product_Quantity]&pri=$result[Product_Price]'>Edit</td>
        		<td><a href='delete.php?name=$result[Product_Name]'>Delete</a></td>
        	 </tr>";      
    }
    ?>
</table>    
</body>
</html>