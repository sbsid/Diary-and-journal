<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>

<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<head>
  <title> about us </title>
  <style>
  .footer {
   position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: pink;
   text-align: center;
}
div.scrollmenu {
  background-color: #DB7093;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: gray;
}
.content {
  min-height: calc(100vh - 70px);
}

</style>

</head>
<body background="diary.jpg">
  <h1 align='center' class="w3-opacity"> MY DIARY </h1>

    <div class="page-header">

    <p>
          <div class="scrollmenu"><center>
  <a href="welcome.php">Home</a>
  <a href="home.php">Global Page </a>
  
  <a href="new.php">New </a>
  <a href="display.php">View </a>
   <a href="dispaly_count.php">Genre Count </a>
 
  <a href="display.php" >Edit </a>
  <a href="display.php">Delete </a>
  
  
  <a href="about.php">About Us</a>
  <a href="logout.php"> Log Out</a>
  </center>
</div>
<div calss="">
<section class="w3-row-padding w3-center w3-light-grey" width=50%>
  <article class="w3-third">
    <p>Saba Siddiqua Sadiq Ahemed Siddiqui</p>
    <img src="saba.webp" alt="Random Name" style="width:100%">
    <p>2018bit501.</p>
  </article>
  </section>
  </div>
<footer class="footer" >
  <p class="w3-medium">
  Designed and programmed by <a href="about.php" target="_blank"> Saba Siddiqua</a>
  </p>
</footer>
<p><h5 align='center'> Saba Siddiqua Sadiq Ahemed Siddiqui <br> <br> Student of 3rd year IT B.tech <br></h5></p>
</body>
</html>

