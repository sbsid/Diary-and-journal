<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>

<html>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<head>
<style>
	.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: lightpink;
  padding: 8px 22px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  -webkit-transition-duration: 0.4s; /* Safari */
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: white; 
  color: black; 
  border: 2px solid #4CAF50;
}

.button1:hover {
  background-color: #4CAF50;
  color: white;
}

	.footer {
   position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: pink;
   text-align: center;
}
div.scrollmenu {
  background-color: #DB7093;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: gray;
}

</style>

</head>
<body background="diary.jpg"> <center>


<h1  class="w3-opacity"> MY DIARY </h1>

    <div class="page-header">

    <p>
       <div class="scrollmenu"><center>
    <a href="welcome.php">Home</a>
  <a href="home.php">Global Page </a>
  
  <a href="new.php">New </a>
  <a href="display.php">View </a>
   <a href="dispaly_count.php">Genre Count </a>
 
  <a href="display.php" >Edit </a>
  <a href="display.php">Delete </a>
  
  
  <a href="about.php">About Us</a>
  <a href="logout.php"> Log Out</a> </center>
</div>
<h2>Create your Posts Here </h2>

<form action="insert.php" method="post">
	
Date: <input style="width:190px;" class="w3-input w3-border w3-hover-pink" type="date" name="date" required><br>
Genre :  <select name="genre" id="genre" value="genre" required>
       <option value=""></option>
   
    <option value="Personal Post">Personal Post</option>
    <option value="Educational">Educational</option>
    <option value="Politics">Politics</option>
    <option value="News">News</option>
  </select><br>
Title : <input style="width:190px;" class="w3-input w3-border w3-hover-pink" type="text" name="title" required><br>
DATA: 
 <textarea style="width:250px;" class="w3-input w3-border w3-hover-pink"  rows=10 cols="30" name="data" ></textarea><br>
<fieldset id="group1">
    <input type="radio" value="public" name="radio" requird> Public<br>
    <input type="radio" value="private" name="radio" required> Private
  </fieldset>

<button class="button button1" color='green'>ENTER DATA</button> 

</form>
</center>

	<?php

	?>
 <footer class="footer" >
  <p class="w3-medium">
  Designed and programmed by <a href="about.php" target="_blank"> Saba Siddiqua</a>
  </p>
</footer>

</body>
</html>