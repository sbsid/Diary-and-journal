<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>

<html>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<head>
	<style>
	.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: pink;
   text-align: center;
}
</style>
  <style>
* {
  box-sizing: border-box;
}

input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  resize: vertical;
}

label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
.content {
  min-height: calc(100vh - 70px);
}
</style>

	</head>
<body background="diary.jpg"> <center>
	<h1  class="w3-opacity"> MY DIARY </h1>
 <div class="scrollmenu"><center>
  <a href="welcome.php">Home</a>
  <a href="home.php">Global Page </a>
  
  <a href="new.php">New </a>
  <a href="display.php">View </a>
   <a href="dispaly_count.php">Genre Count </a>
 
  <a href="display.php" >Edit </a>
  <a href="display.php">Delete </a>
  
  
  <a href="about.php">About Us</a>
  <a href="logout.php"> Log Out</a>
  </center>
</div>
<style>
	td{
		padding:10px;
	}
	div.scrollmenu {
  background-color: #DB7093;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: gray;
}

</style>
<?php
require_once "config.php";

error_reporting(0);
$name=$_SESSION["username"];
$f=$name."post";
$query="SELECT*FROM $name ";
$data=mysqli_query($link,$query);
$total=mysqli_num_rows($data);

$result=mysqli_fetch_assoc($data);


if($total != 0 )
{
	?>
	<div class="content">
<table>
	<tr>
		<th>Date</th>
		<th>Title</th>
		<th>Genre</th>
		<th>Access Type</th>
		
		<th>Edit</th>
		<th>Delete</th>
	</tr>



	<?php
	while($result=mysqli_fetch_assoc($data)){
		echo "<tr>
		<td>".$result['dates']."</td>
		<td>".$result['title_post']."</td>
		<td>".$result['genre']."</td>
		<td>".$result['access']."</td>
	
	
		<td><a href='update.php?da=$result[dates]&po=$result[post]&tit=$result[title_post]'>Edit</td>
		<td><a href='delete.php?da=$result[dates]&ge=$result[genre]'>Delete</a></td>
	</tr>";

	}

}
else
{
	echo "no records";
}
echo "<br><br><br>";
?>
</table>
</center>
</div>
<footer class="footer" >
  <p class="w3-medium">
  Designed and programmed by <a href="about.php" target="_blank"> Saba Siddiqua</a>
  </p>
</footer>

</body></html>