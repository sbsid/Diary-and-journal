<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>

<?php
require_once "config.php";

error_reporting(0);
 $_GET['da'];
 $_GET['po'];

?>
<html>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/3/w3.css">
<head>
   <style>
      .footer {
   position: relative;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: grey;
   color: pink;
   text-align: center;
}
.button {
  background-color: purple;
  border: pink;
  color: white;
  padding: 16px 32px;
  text-align: center;
  font-size: 16px;
  margin: 4px 2px;
  opacity: 0.6;
  transition: 0.3s;
  display: inline-block;
  text-decoration: none;
  cursor: pointer;
}

.button:hover {opacity: 1}

</style>
  <style>
* {
  box-sizing: border-box;
}


/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
   
    margin-top: 0;
  }
}
div.scrollmenu {
  background-color: #DB7093;
  overflow: auto;
  white-space: nowrap;
}

div.scrollmenu a {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px;
  text-decoration: none;
}

div.scrollmenu a:hover {
  background-color: gray;
}

</style>

   </head>
<body background="diary.jpg"> <center>
	<h1  class="w3-opacity"> MY DIARY </h1>
 <div class="scrollmenu"><center>
   <a href="welcome.php">Home</a>
  <a href="home.php">Global Page </a>
  
  <a href="new.php">New </a>
  <a href="display.php">View </a>
   <a href="dispaly_count.php">Genre Count </a>
 
  <a href="display.php" >Edit </a>
  <a href="display.php">Delete </a>
  
  
  <a href="about.php">About Us</a>
  <a href="logout.php"> Log Out</a>  </center>
</div>
   <form  method="GET">
       <br>
      <b>Date</b> <br><input type="text" name="dates" value="<?php echo $_GET['da']; ?>" readonly><br><br><br>
      <b>Title</b> <br><input type="text" name="title" value="<?php echo $_GET['tit']; ?>" ><br>
      <b>
         Post</b><br>
       <textarea rows="10" cols="50" name="post"><?php echo $_GET['po']; ?> </textarea>
      <br><br>
      <input class="button" style="vertical-align:middle" type="submit" name="submit" value="Update">
   </form>

   <?php
   $name=$_SESSION["username"];

   if($_GET['submit'])
   {
      $id=$_GET['id'];
       $dates= $_GET['dates'];
      $titl= $_GET['title'];
      $post=$_GET['post'];
      $query="update $name set dates='$dates',post='$post',title_post='$titl' where dates='$dates'";
      $query1="update home set dates_1='$dates',tweet='$post' ,title_of_post='$titl' where dates_1='$dates' and user_name='$name'";
      $data1=mysqli_query($link,$query1);
      
      $data=mysqli_query($link,$query);
      if($data and $data1){
         
                 echo "<script type='text/javascript'>window.top.location='display.php';</script>"; exit;
            
 
      }
      else
      {
         echo " not updated";
      }

   }
   ?>
</center>
 <footer class="footer" >
  <p class="w3-medium">
  Designed and programmed by <a href="about.php" target="_blank"> Saba Siddiqua</a>
  </p>
</footer>

   </body>
</html>