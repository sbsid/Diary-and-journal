-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: diary
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `diary`
--


--
-- Table structure for table `123post`
--

DROP TABLE IF EXISTS `123post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `123post` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `123post`
--

LOCK TABLES `123post` WRITE;
/*!40000 ALTER TABLE `123post` DISABLE KEYS */;
INSERT INTO `123post` VALUES ('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30),('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `123post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `321post`
--

DROP TABLE IF EXISTS `321post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `321post` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `321post`
--

LOCK TABLES `321post` WRITE;
/*!40000 ALTER TABLE `321post` DISABLE KEYS */;
INSERT INTO `321post` VALUES ('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30),('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30),('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `321post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Asdf`
--

DROP TABLE IF EXISTS `Asdf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Asdf` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Asdf`
--

LOCK TABLES `Asdf` WRITE;
/*!40000 ALTER TABLE `Asdf` DISABLE KEYS */;
INSERT INTO `Asdf` VALUES ('0000-00-00','','','',''),('2019-08-28','Ú©ÛÛŒÚº Ø¨Û’ Ú©Ù†Ø§Ø± Ø³Û’ Ø±ØªØ¬Ú¯Û’ Ú©ÛÛŒÚº Ø²Ø± Ù†Ú¯Ø§Ø± Ø³Û’ Ø®ÙˆØ§Ø¨ Ø¯Û’ Û”Û”Û”Û”Û”Û” ØªÛŒØ±Ø§ Ú©ÛŒØ§ Ø§ØµÙˆÙ„ ÛÛ’ Ø²Ù†Ø¯Ú¯ÛŒ Ù…Ø¬Ú¾Û’ Ú©ÙˆÙ† Ø§Ø³ Ú©Ø§ Ø¬ÙˆØ§Ø¨ Ø¯Û’ ','Educational','public','Ø´Ø¹Ø±');
/*!40000 ALTER TABLE `Asdf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Asdfpost`
--

DROP TABLE IF EXISTS `Asdfpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Asdfpost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Asdfpost`
--

LOCK TABLES `Asdfpost` WRITE;
/*!40000 ALTER TABLE `Asdfpost` DISABLE KEYS */;
INSERT INTO `Asdfpost` VALUES ('Personal Post',30),('Personal Post',30),('Educational',29),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Asdfpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ayesha`
--

DROP TABLE IF EXISTS `Ayesha`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ayesha` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ayesha`
--

LOCK TABLES `Ayesha` WRITE;
/*!40000 ALTER TABLE `Ayesha` DISABLE KEYS */;
INSERT INTO `Ayesha` VALUES ('1903-09-12','Bissmillah','kok','lol','Khan');
/*!40000 ALTER TABLE `Ayesha` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ayeshapost`
--

DROP TABLE IF EXISTS `Ayeshapost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ayeshapost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ayeshapost`
--

LOCK TABLES `Ayeshapost` WRITE;
/*!40000 ALTER TABLE `Ayeshapost` DISABLE KEYS */;
INSERT INTO `Ayeshapost` VALUES ('empty',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30),('empty',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30),('empty',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Ayeshapost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lavi`
--

DROP TABLE IF EXISTS `Lavi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lavi` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lavi`
--

LOCK TABLES `Lavi` WRITE;
/*!40000 ALTER TABLE `Lavi` DISABLE KEYS */;
INSERT INTO `Lavi` VALUES ('1903-09-12','Bissmillah','kok','lol','Khan'),('2019-08-03','Apolo mission ','Politics','private','Polo'),('2019-08-04','She looks like a blue parrot\r\nWould you come fly to me?\r\nI want some good day, good day, good day\r\nGood day, good day\r\nLooks like a winter bear\r\nYou sleep so happily\r\nI wish you good night, good night, good night\r\nGood night, good night','Personal Post','public','Nice world'),('2019-08-22','Koko','Politics','public','Cyber World'),('2019-08-24','Hi I am lavi I am a really good\r\nPhotographer and I do so many things that may like you all hone','News','public','Photography Blog');
/*!40000 ALTER TABLE `Lavi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lavipost`
--

DROP TABLE IF EXISTS `Lavipost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lavipost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lavipost`
--

LOCK TABLES `Lavipost` WRITE;
/*!40000 ALTER TABLE `Lavipost` DISABLE KEYS */;
INSERT INTO `Lavipost` VALUES ('empty',30),('Personal Post',29),('Educational',29),('Politics',25),('News',29);
/*!40000 ALTER TABLE `Lavipost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Muqeet`
--

DROP TABLE IF EXISTS `Muqeet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Muqeet` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Muqeet`
--

LOCK TABLES `Muqeet` WRITE;
/*!40000 ALTER TABLE `Muqeet` DISABLE KEYS */;
INSERT INTO `Muqeet` VALUES ('0000-00-00','','','',''),('2019-09-20','Ccghbfd','Personal Post','private','Sfffr'),('2019-09-21','Aslkm ','Educational','public','Gh');
/*!40000 ALTER TABLE `Muqeet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Muqeetpost`
--

DROP TABLE IF EXISTS `Muqeetpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Muqeetpost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Muqeetpost`
--

LOCK TABLES `Muqeetpost` WRITE;
/*!40000 ALTER TABLE `Muqeetpost` DISABLE KEYS */;
INSERT INTO `Muqeetpost` VALUES ('Personal Post',29),('Personal Post',29),('Educational',29),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Muqeetpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rani`
--

DROP TABLE IF EXISTS `Rani`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rani` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rani`
--

LOCK TABLES `Rani` WRITE;
/*!40000 ALTER TABLE `Rani` DISABLE KEYS */;
INSERT INTO `Rani` VALUES ('1903-09-12','Bissmillah','kok','lol','Khan'),('2019-08-20','Months after his release, he is only now fully rebuilding his life after the setback devastated him and his family of .','Personal Post','public','Personal Diary in java');
/*!40000 ALTER TABLE `Rani` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ranipost`
--

DROP TABLE IF EXISTS `Ranipost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Ranipost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ranipost`
--

LOCK TABLES `Ranipost` WRITE;
/*!40000 ALTER TABLE `Ranipost` DISABLE KEYS */;
INSERT INTO `Ranipost` VALUES ('empty',30),('Personal Post',28),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Ranipost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Saba`
--

DROP TABLE IF EXISTS `Saba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Saba` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Saba`
--

LOCK TABLES `Saba` WRITE;
/*!40000 ALTER TABLE `Saba` DISABLE KEYS */;
INSERT INTO `Saba` VALUES ('0000-00-00','','','','');
/*!40000 ALTER TABLE `Saba` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sabapost`
--

DROP TABLE IF EXISTS `Sabapost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sabapost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sabapost`
--

LOCK TABLES `Sabapost` WRITE;
/*!40000 ALTER TABLE `Sabapost` DISABLE KEYS */;
INSERT INTO `Sabapost` VALUES ('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Sabapost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sana`
--

DROP TABLE IF EXISTS `Sana`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sana` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sana`
--

LOCK TABLES `Sana` WRITE;
/*!40000 ALTER TABLE `Sana` DISABLE KEYS */;
INSERT INTO `Sana` VALUES ('1903-09-12','Bissmillah','kok','lol','Khan'),('2019-08-24','They Messed Up My Life\": Man Who Was Jailed For Bringing Honey To US\r\nLeon Haughton likes honey in his tea. Which is why during his Christmas visit to relatives in Jamaica, he made his regular stop and bought three bottles from a favorite roadsid','News','public','Today news'),('2019-08-25','She looks like a blue parrot\r\nWould you come fly to me?\r\nI want some good day, good day, good day\r\nGood day, good day\r\nLooks like a winter bear\r\nYou sleep so happily\r\nI wish you good night, good night, good night\r\nGood night, good night','Personal Post','public','Lala post');
/*!40000 ALTER TABLE `Sana` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sanapost`
--

DROP TABLE IF EXISTS `Sanapost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sanapost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sanapost`
--

LOCK TABLES `Sanapost` WRITE;
/*!40000 ALTER TABLE `Sanapost` DISABLE KEYS */;
INSERT INTO `Sanapost` VALUES ('empty',30),('Personal Post',29),('Educational',30),('Politics',30),('News',29),('empty',30),('Personal Post',29),('Educational',30),('Politics',30),('News',29);
/*!40000 ALTER TABLE `Sanapost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sdk`
--

DROP TABLE IF EXISTS `Sdk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sdk` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sdk`
--

LOCK TABLES `Sdk` WRITE;
/*!40000 ALTER TABLE `Sdk` DISABLE KEYS */;
INSERT INTO `Sdk` VALUES ('0000-00-00','','','',''),('2020-03-08','Jj','Educational','public','Jj');
/*!40000 ALTER TABLE `Sdk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sdkpost`
--

DROP TABLE IF EXISTS `Sdkpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sdkpost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sdkpost`
--

LOCK TABLES `Sdkpost` WRITE;
/*!40000 ALTER TABLE `Sdkpost` DISABLE KEYS */;
INSERT INTO `Sdkpost` VALUES ('Personal Post',29),('Personal Post',29),('Educational',29),('Politics',30),('News',30),('Personal Post',29),('Personal Post',29),('Educational',29),('Politics',30),('News',30),('Personal Post',29),('Personal Post',29),('Educational',29),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Sdkpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shruti`
--

DROP TABLE IF EXISTS `Shruti`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Shruti` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shruti`
--

LOCK TABLES `Shruti` WRITE;
/*!40000 ALTER TABLE `Shruti` DISABLE KEYS */;
INSERT INTO `Shruti` VALUES ('1903-09-12','Bissmillah','kok','lol','Khan'),('2019-08-26','Mi rutxmhcmhxhtsjts','Educational','public','Education sys');
/*!40000 ALTER TABLE `Shruti` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Shrutipost`
--

DROP TABLE IF EXISTS `Shrutipost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Shrutipost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Shrutipost`
--

LOCK TABLES `Shrutipost` WRITE;
/*!40000 ALTER TABLE `Shrutipost` DISABLE KEYS */;
INSERT INTO `Shrutipost` VALUES ('empty',30),('Personal Post',30),('Educational',29),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Shrutipost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Siddiquiat`
--

DROP TABLE IF EXISTS `Siddiquiat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Siddiquiat` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Siddiquiat`
--

LOCK TABLES `Siddiquiat` WRITE;
/*!40000 ALTER TABLE `Siddiquiat` DISABLE KEYS */;
INSERT INTO `Siddiquiat` VALUES ('0000-00-00','','','','');
/*!40000 ALTER TABLE `Siddiquiat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Siddiquiatpost`
--

DROP TABLE IF EXISTS `Siddiquiatpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Siddiquiatpost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Siddiquiatpost`
--

LOCK TABLES `Siddiquiatpost` WRITE;
/*!40000 ALTER TABLE `Siddiquiatpost` DISABLE KEYS */;
INSERT INTO `Siddiquiatpost` VALUES ('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `Siddiquiatpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abbu`
--

DROP TABLE IF EXISTS `abbu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abbu` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abbu`
--

LOCK TABLES `abbu` WRITE;
/*!40000 ALTER TABLE `abbu` DISABLE KEYS */;
INSERT INTO `abbu` VALUES ('0000-00-00','','','',''),('2019-08-31','Good Job','Educational','public','Better'),('2019-09-01','aslkm','Personal Post','private','Abbu');
/*!40000 ALTER TABLE `abbu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `abbupost`
--

DROP TABLE IF EXISTS `abbupost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abbupost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `abbupost`
--

LOCK TABLES `abbupost` WRITE;
/*!40000 ALTER TABLE `abbupost` DISABLE KEYS */;
INSERT INTO `abbupost` VALUES ('Personal Post',29),('Personal Post',29),('Educational',29),('Politics',30),('News',30);
/*!40000 ALTER TABLE `abbupost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home`
--

DROP TABLE IF EXISTS `home`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `home` (
  `user_name` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tweet` varchar(5000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `post_type` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dates_1` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_of_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home`
--

LOCK TABLES `home` WRITE;
/*!40000 ALTER TABLE `home` DISABLE KEYS */;
INSERT INTO `home` VALUES ('','','','',NULL),('samsung','Web Page: A web page is a document which is commonly written in HTML and translated by a web browser. A web page can be identified by entering an URL. A Web page can be of the static or dynamic type. With the help of HTML Web Page: A web page is a document which is commonly written in HTML and translated by a web browser. A web page can be identified by entering an URL. A Web page can be of the static or dynamic type. With the help of HTMLWeb Page: A web page is a document which is commonly written in HTML and translated by a web browser. A web page can be identified by entering an URL. A Web page can be of the static or dynamic type. With the help of HTML    ','Personal Post','2019-08-25','Todays News'),('Lavi','Koko','Politics','2019-08-22','Cyber World'),('Lavi','She looks like a blue parrot\r\nWould you come fly to me?\r\nI want some good day, good day, good day\r\nGood day, good day\r\nLooks like a winter bear\r\nYou sleep so happily\r\nI wish you good night, good night, good night\r\nGood night, good night','Personal Post','2019-08-04','Nice world'),('Sana','She looks like a blue parrot\r\nWould you come fly to me?\r\nI want some good day, good day, good day\r\nGood day, good day\r\nLooks like a winter bear\r\nYou sleep so happily\r\nI wish you good night, good night, good night\r\nGood night, good night','Personal Post','2019-08-25','Lala post'),('Rani','Months after his release, he is only now fully rebuilding his life after the setback devastated him and his family of .','Personal Post','2019-08-20','Personal Diary in java'),('Asdf','Ú©ÛÛŒÚº Ø¨Û’ Ú©Ù†Ø§Ø± Ø³Û’ Ø±ØªØ¬Ú¯Û’ Ú©ÛÛŒÚº Ø²Ø± Ù†Ú¯Ø§Ø± Ø³Û’ Ø®ÙˆØ§Ø¨ Ø¯Û’ Û”Û”Û”Û”Û”Û” ØªÛŒØ±Ø§ Ú©ÛŒØ§ Ø§ØµÙˆÙ„ ÛÛ’ Ø²Ù†Ø¯Ú¯ÛŒ Ù…Ø¬Ú¾Û’ Ú©ÙˆÙ† Ø§Ø³ Ú©Ø§ Ø¬ÙˆØ§Ø¨ Ø¯Û’ ','Educational','2019-08-28','Ø´Ø¹Ø±'),('Sam sid','\r\nNeed some motivation 4 study???','Personal Post','2019-09-01','Learning'),('Sam sid','Need some motivation???? Read the conversation of Lal Bahadur Shastri and one of the interviewer\r\n','Educational','2019-08-31','Learning'),('abbu','Good Job','Educational','2019-08-31','Better'),('saba','Allah ka shukar hai','Personal Post','2019-09-11','Alhmd'),('Muqeet','Aslkm ','Educational','2019-09-21','Gh'),('Sdk','Jj','Educational','2020-03-08','Jj');
/*!40000 ALTER TABLE `home` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mxdihaa01`
--

DROP TABLE IF EXISTS `mxdihaa01`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mxdihaa01` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mxdihaa01`
--

LOCK TABLES `mxdihaa01` WRITE;
/*!40000 ALTER TABLE `mxdihaa01` DISABLE KEYS */;
INSERT INTO `mxdihaa01` VALUES ('0000-00-00','','','','');
/*!40000 ALTER TABLE `mxdihaa01` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mxdihaa01post`
--

DROP TABLE IF EXISTS `mxdihaa01post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mxdihaa01post` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mxdihaa01post`
--

LOCK TABLES `mxdihaa01post` WRITE;
/*!40000 ALTER TABLE `mxdihaa01post` DISABLE KEYS */;
INSERT INTO `mxdihaa01post` VALUES ('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `mxdihaa01post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pone`
--

DROP TABLE IF EXISTS `pone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pone` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pone`
--

LOCK TABLES `pone` WRITE;
/*!40000 ALTER TABLE `pone` DISABLE KEYS */;
INSERT INTO `pone` VALUES ('0000-00-00','','','',''),('2019-08-29','aagai ghadi hai dekho sabse badi ....\r\ndo kadam pe hai dekho jeet khadi...\r\nha muze kabse intezaar tha ...Aaj ki sham ka... Ab dekho kya karta hai ye banda Hindustan ka....','Personal Post','private','My rap');
/*!40000 ALTER TABLE `pone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ponepost`
--

DROP TABLE IF EXISTS `ponepost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ponepost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ponepost`
--

LOCK TABLES `ponepost` WRITE;
/*!40000 ALTER TABLE `ponepost` DISABLE KEYS */;
INSERT INTO `ponepost` VALUES ('Personal Post',29),('Personal Post',29),('Educational',30),('Politics',30),('News',30),('Personal Post',29),('Personal Post',29),('Educational',30),('Politics',30),('News',30),('Personal Post',29),('Personal Post',29),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `ponepost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pooja`
--

DROP TABLE IF EXISTS `pooja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pooja` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pooja`
--

LOCK TABLES `pooja` WRITE;
/*!40000 ALTER TABLE `pooja` DISABLE KEYS */;
INSERT INTO `pooja` VALUES ('0000-00-00','','','',''),('1903-09-12','Bissmillah','kok','lol','Khan'),('2019-08-26',' today is php dont have any submission','Educational','public','php');
/*!40000 ALTER TABLE `pooja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pooja123`
--

DROP TABLE IF EXISTS `pooja123`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pooja123` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pooja123`
--

LOCK TABLES `pooja123` WRITE;
/*!40000 ALTER TABLE `pooja123` DISABLE KEYS */;
INSERT INTO `pooja123` VALUES ('0000-00-00','','','','');
/*!40000 ALTER TABLE `pooja123` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pooja123post`
--

DROP TABLE IF EXISTS `pooja123post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pooja123post` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pooja123post`
--

LOCK TABLES `pooja123post` WRITE;
/*!40000 ALTER TABLE `pooja123post` DISABLE KEYS */;
INSERT INTO `pooja123post` VALUES ('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30),('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `pooja123post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poojapost`
--

DROP TABLE IF EXISTS `poojapost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poojapost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poojapost`
--

LOCK TABLES `poojapost` WRITE;
/*!40000 ALTER TABLE `poojapost` DISABLE KEYS */;
INSERT INTO `poojapost` VALUES ('empty',30),('Personal Post',30),('Educational',29),('Politics',30),('News',30),('Personal Post',30),('Personal Post',30),('Educational',30),('Politics',30),('News',30);
/*!40000 ALTER TABLE `poojapost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pooju`
--

DROP TABLE IF EXISTS `pooju`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pooju` (
  `dates` date NOT NULL,
  `post` varchar(5000) NOT NULL,
  `genre` varchar(20) NOT NULL,
  `access` varchar(20) DEFAULT NULL,
  `title_post` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pooju`
--

LOCK TABLES `pooju` WRITE;
/*!40000 ALTER TABLE `pooju` DISABLE KEYS */;
INSERT INTO `pooju` VALUES ('0000-00-00','','','',''),('2019-08-20','hi , this the first data that i have submitted into this site after hosting','Educational','private','first time hosting experience');
/*!40000 ALTER TABLE `pooju` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poojupost`
--

DROP TABLE IF EXISTS `poojupost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poojupost` (
  `genre` varchar(20) NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poojupost`
--

LOCK TABLES `poojupost` WRITE;
/*!40000 ALTER TABLE `poojupost` DISABLE KEYS */;
INSERT INTO `poojupost` VALUES ('Personal Post',30),('Personal Post',30),('Educational',29),('Politics',30),('News',30);
/*!40000 ALTER TABLE `poojupost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saba`
--

DROP TABLE IF EXISTS `saba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saba` (
  `dates` date NOT NULL,
  `post` varchar(5000) COLLATE utf8_unicode_ci NOT NULL,
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `access` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title_post` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`dates`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saba`
--

LOCK TABLES `saba` WRITE;
/*!40000 ALTER TABLE `saba` DISABLE KEYS */;
INSERT INTO `saba` VALUES ('1903-09-12','Bissmillah','kok','lol','Khan'),('2019-09-11','Allah ka shukar hai','Personal Post','public','Alhmd');
/*!40000 ALTER TABLE `saba` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sabapost`
--

DROP TABLE IF EXISTS `sabapost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sabapost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sabapost`
--

LOCK TABLES `sabapost` WRITE;
/*!40000 ALTER TABLE `sabapost` DISABLE KEYS */;
INSERT INTO `sabapost` VALUES ('empty',30),('Personal Post',25),('Educational',28),('Politics',28),('News',28);
/*!40000 ALTER TABLE `sabapost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `samsungpost`
--

DROP TABLE IF EXISTS `samsungpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `samsungpost` (
  `genre` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `samsungpost`
--

LOCK TABLES `samsungpost` WRITE;
/*!40000 ALTER TABLE `samsungpost` DISABLE KEYS */;
INSERT INTO `samsungpost` VALUES ('empty',30),('Personal Post',30),('Educational',29),('Politics',29),('News',27);
/*!40000 ALTER TABLE `samsungpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (33,'sakizu','0192023a7bbd73250516f069df18b500 ','2019-08-25 17:50:14'),(34,'saba','$2y$10$YljMs0GOLODCrk9bpaKYm.CadIkmD5GLHvJZOY5wcKQWb0R0WO3Dq','2019-08-25 17:53:26'),(35,'Lavi','$2y$10$FefHN.aIBwCW4n0z7gYqieHIf0SoBnONgbwbiJNYhYfBU5HX22mUK','2019-08-25 17:59:23'),(36,'Sana','$2y$10$8sk4TDrn/zfGZYrkheopau6oMrvKOFpLE3YGL9R3YzVp0m9mQDt2a','2019-08-25 18:11:26'),(37,'Rani','$2y$10$l5HjKpV6YBYuhKggzmSCSespPF5FCMMGFhakX5hfNiYsjuctmKyj.','2019-08-25 18:17:45'),(38,'Shruti','$2y$10$hrO.E1JIIF.HVcyLgHuRoO.pWVxeZL6CWlLpsW3Bgrzg1AsXoDTMW','2019-08-26 03:33:57'),(39,'pooja','$2y$10$AUM2asfXLJukQnk6Qkk40Oicir9ahp8oMNFPeUVINgOlj0E8qI4ge','2019-08-26 04:52:21'),(40,'Ayesha','$2y$10$7dtShrpLyFiDUbRXLOIk2uA38zTrH0D9ly3uOI0bSAChFOePZh7wa','2019-08-27 11:56:46'),(48,'pooju','$2y$10$w4pP/KFXYtSlw/epjtyNw.AMDC68nPzyXDygblJoFTqQlhKtSTIxK','2019-08-27 22:22:40'),(49,'Asdf','$2y$10$mRgny1StOh5WoA2o/OupXuoMGIJdDR047odYQbrK0gFmLl6E./m3m','2019-08-28 12:03:15'),(50,'321','$2y$10$5X1A1erj71EScKXooEJuhOajhLV.ldbTainqvCZpcMmtv0TUbb5JO','2019-08-28 21:54:55'),(51,'pone','$2y$10$y2//v13u38Eatj285LYq4OtunT.iGyuqv448DUpIPMFsIsoCAlmy2','2019-08-29 21:13:47'),(52,'pooja123','$2y$10$Yd0xILpNtv2PDbOX1zqMA.RM6NCeAUiyyRIyydZJxo7E19LY5IZG6','2019-08-30 11:12:06'),(53,'Sam sid','$2y$10$AVAdunuEer/FAbR0m6/.H.8HKUaq6QWCX.FN4j7..T.fXccIQlySu','2019-09-01 22:22:53'),(54,'abbu','$2y$10$Ch8pwdXOl12/Wo.5sQTKkOxe014bGOHhBE30qYCoWi6mZBV6Tcm6a','2019-09-01 22:33:57'),(55,'Siddiquiat','$2y$10$phFkf5eCDXZeKeLuw6OCkunuvcQS/PsK55E19x5tce4q.oa74/r/a','2019-09-04 19:32:13'),(56,'Muqeet','$2y$10$V8vuzgxsD/xFFGP6R/AsWuUGNg7uUTWqQVfanpeCR.6mIl3fJFAFW','2019-09-21 22:11:24'),(57,'Ayesha Pathan','$2y$10$ut9upMNkGJWLlQKcJkq7UecjmSxSkU0euJaRP5BRJ9A8QipfGrDYa','2019-09-26 09:24:26'),(58,'mxdihaa01','$2y$10$lox1fpSkx9jYgBhQd.S81ejiy8nIkV10mT3NCfW4xOWDrI6ZweNOy','2019-12-09 21:35:24'),(59,'Sdk','$2y$10$JxUAVxEXxd/WW2UNQFb0I.BJlKSENN0Tcq18qOOLRZbUQ4ZkOegYm','2020-03-12 22:23:51');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-12 22:22:25

